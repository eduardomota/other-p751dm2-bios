HOW-TO: - Create an FREE-DOS USB flash-drive (To do so we recommend the Software'Rufus').
        - Add all files without folder directly to the root of the flash-drive. 
        - Connect your Power Supply!!!
          (Remove old BIOS/HDD Passwords and disable UEFI)
        - During boot press "F7" to select the flash drive.
        - Type "step1" and hit "Enter". (The system will auto-reboot)
        - Once again select the flash drive, type "step2" and hit "enter".         
        - Follow the on-screen instructions. (Confirm with yes in case of ID Mismatch)
          (The system may beep during the flashing process, this is normal)
        - After the system has completed & auto-shutdown, remove AC Power for 30s!!!
          (The first boot takes a little longer and it will automatically reboot.)
        - Press F2 to Enter the BIOS Setup Menu and press F3 to load the setup defaults.
        - Make important changes like UEFI & RAID to match your previous setup.
        - Be Happy & Enjoy! :)